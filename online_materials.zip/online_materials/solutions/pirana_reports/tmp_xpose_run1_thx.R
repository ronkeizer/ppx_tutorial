#--- Initialize R / Xpose  ---
setwd('C:/users/Ron/Dropbox/Research/Manuscripts/2012_Tutorial_PSP/online/solutions2')
library(xpose4)
new.runno <- '1' 
newdb <- xpose.data(new.runno)
newnam <- paste('xpdb', new.runno, sep = '')
assign(pos = 1, newnam, newdb)
assign(pos = 1, '.cur.db', newdb)
setwd('C:/users/Ron/Dropbox/Research/Manuscripts/2012_Tutorial_PSP/online/solutions2/pirana_reports')
#-----------------------------


#--- Start Xpose commands list  ----------
pdf (file="C:/users/Ron/Dropbox/Research/Manuscripts/2012_Tutorial_PSP/online/solutions2/pirana_reports/run1_ind.plots_01.mod.pdf")
ind.plots(object=xpdb1, layout=c(2,3)) 
dev.off()
